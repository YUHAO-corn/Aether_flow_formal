// API客户端工具

// 基础URL
const BASE_URL = 'http://localhost:3000/api';

// 创建请求
const createRequest = (url, options = {}) => {
  const defaultOptions = {
    headers: {
      'Content-Type': 'application/json',
    },
    ...options
  };

  // 从localStorage获取token
  const token = localStorage.getItem('token');
  
  // 如果token存在，添加到请求头
  if (token) {
    defaultOptions.headers.Authorization = `Bearer ${token}`;
  }

  return fetch(`${BASE_URL}${url}`, defaultOptions)
    .then(response => {
      if (!response.ok) {
        // 处理401未授权错误
        if (response.status === 401) {
          // 清除本地存储的token
          localStorage.removeItem('token');
          localStorage.removeItem('user');
        }
        return Promise.reject(new Error(`HTTP error! status: ${response.status}`));
      }
      return response.json();
    });
};

// 认证相关API
const authAPI = {
  // 用户注册
  register: function(userData) {
    return createRequest('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  },
  
  // 用户登录
  login: function(credentials) {
    return createRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials)
    });
  },
  
  // 获取当前用户信息
  getCurrentUser: function() {
    return createRequest('/auth/me', { method: 'GET' });
  },
  
  // 更新用户信息
  updateUser: function(userData) {
    return createRequest('/auth/updateMe', {
      method: 'PATCH',
      body: JSON.stringify(userData)
    });
  },
  
  // 用户登出
  logout: function() {
    return createRequest('/auth/logout', { method: 'POST' });
  }
};

// 提示词相关API
const promptAPI = {
  // 获取提示词列表
  getPrompts: function(params) {
    const queryString = params ? `?${new URLSearchParams(params).toString()}` : '';
    return createRequest(`/prompts${queryString}`, { method: 'GET' });
  },
  
  // 创建提示词
  createPrompt: function(promptData) {
    return createRequest('/prompts', {
      method: 'POST',
      body: JSON.stringify(promptData)
    });
  },
  
  // 自动保存提示词
  autoSavePrompt: function(promptData) {
    return createRequest('/prompts/auto-save', {
      method: 'POST',
      body: JSON.stringify(promptData)
    });
  },
  
  // 批量获取提示词
  getBatchPrompts: function(ids) {
    return createRequest('/prompts/batch', {
      method: 'POST',
      body: JSON.stringify({ ids })
    });
  },
  
  // 获取最近使用的提示词
  getRecentPrompts: function() {
    return createRequest('/prompts/recent', { method: 'GET' });
  },
  
  // 快速搜索提示词
  quickSearchPrompts: function(query) {
    return createRequest(`/prompts/quick-search?query=${encodeURIComponent(query)}`, { method: 'GET' });
  },
  
  // 优化提示词
  enhancePrompt: function(promptData) {
    return createRequest('/prompts/enhance', {
      method: 'POST',
      body: JSON.stringify(promptData)
    });
  },
  
  // 获取单个提示词
  getPrompt: function(id) {
    return createRequest(`/prompts/${id}`, { method: 'GET' });
  },
  
  // 更新提示词
  updatePrompt: function(id, promptData) {
    return createRequest(`/prompts/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(promptData)
    });
  },
  
  // 删除提示词
  deletePrompt: function(id) {
    return createRequest(`/prompts/${id}`, { method: 'DELETE' });
  },
  
  // 切换收藏状态
  toggleFavorite: function(id) {
    return createRequest(`/prompts/${id}/favorite`, { method: 'PATCH' });
  },
  
  // 增加使用次数
  incrementUsage: function(id) {
    return createRequest(`/prompts/${id}/usage`, { method: 'PATCH' });
  }
};

// 标签相关API
const tagAPI = {
  // 获取标签列表
  getTags: function() {
    return createRequest('/tags', { method: 'GET' });
  },
  
  // 创建标签
  createTag: function(tagData) {
    return createRequest('/tags', {
      method: 'POST',
      body: JSON.stringify(tagData)
    });
  },
  
  // 获取单个标签
  getTag: function(id) {
    return createRequest(`/tags/${id}`, { method: 'GET' });
  },
  
  // 更新标签
  updateTag: function(id, tagData) {
    return createRequest(`/tags/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(tagData)
    });
  },
  
  // 删除标签
  deleteTag: function(id) {
    return createRequest(`/tags/${id}`, { method: 'DELETE' });
  },
  
  // 获取标签的提示词
  getTagPrompts: function(id, params) {
    const queryString = params ? `?${new URLSearchParams(params).toString()}` : '';
    return createRequest(`/tags/${id}/prompts${queryString}`, { method: 'GET' });
  }
};

// 提示词优化相关API
const optimizationAPI = {
  // 获取客户端配置
  getConfig: function() {
    return createRequest('/prompt-optimization/config', { method: 'GET' });
  },
  
  // 优化提示词
  optimizePrompt: function(promptData) {
    return createRequest('/prompt-optimization', {
      method: 'POST',
      body: JSON.stringify(promptData)
    });
  },
  
  // 获取优化历史
  getHistory: function() {
    return createRequest('/prompt-optimization/history', { method: 'GET' });
  },
  
  // 获取单个优化历史
  getHistoryById: function(id) {
    return createRequest(`/prompt-optimization/history/${id}`, { method: 'GET' });
  },
  
  // 评价优化结果
  rateOptimization: function(id, ratingData) {
    return createRequest(`/prompt-optimization/history/${id}/rate`, {
      method: 'POST',
      body: JSON.stringify(ratingData)
    });
  },
  
  // 管理API密钥
  manageApiKey: function(keyData) {
    return createRequest('/prompt-optimization/api-keys', {
      method: 'POST',
      body: JSON.stringify(keyData)
    });
  },
  
  // 获取API密钥
  getApiKeys: function() {
    return createRequest('/prompt-optimization/api-keys', { method: 'GET' });
  },
  
  // 删除API密钥
  deleteApiKey: function(id) {
    return createRequest(`/prompt-optimization/api-keys/${id}`, { method: 'DELETE' });
  }
};

// 导出API
self.authAPI = authAPI;
self.promptAPI = promptAPI;
self.tagAPI = tagAPI;
self.optimizationAPI = optimizationAPI; 