// API客户端工具

// 基础URL
const BASE_URL = 'http://localhost:3000/api';

// 创建请求
const createRequest = (url, options = {}) => {
  const defaultOptions = {
    headers: {
      'Content-Type': 'application/json',
    },
    ...options
  };

  // 从localStorage获取token
  const token = localStorage.getItem('token');
  
  // 如果token存在，添加到请求头
  if (token) {
    defaultOptions.headers.Authorization = `Bearer ${token}`;
  }

  return fetch(`${BASE_URL}${url}`, defaultOptions)
    .then(response => {
      if (!response.ok) {
        // 处理401未授权错误
        if (response.status === 401) {
          // 清除本地存储的token
          localStorage.removeItem('token');
          localStorage.removeItem('user');
        }
        return Promise.reject(new Error(`HTTP error! status: ${response.status}`));
      }
      return response.json();
    });
};

// 认证相关API
export const authAPI = {
  // 用户注册
  register: (userData) => {
    return createRequest('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  },
  
  // 用户登录
  login: (credentials) => {
    return createRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials)
    });
  },
  
  // 获取当前用户信息
  getCurrentUser: () => {
    return createRequest('/auth/me', { method: 'GET' });
  },
  
  // 更新用户信息
  updateUser: (userData) => {
    return createRequest('/auth/updateMe', {
      method: 'PATCH',
      body: JSON.stringify(userData)
    });
  },
  
  // 用户登出
  logout: () => {
    return createRequest('/auth/logout', { method: 'POST' });
  }
};

// 提示词相关API
const promptAPI = {
  // 获取提示词列表
  getPrompts: (params) => {
    const queryString = params ? `?${new URLSearchParams(params).toString()}` : '';
    return createRequest(`/prompts${queryString}`, { method: 'GET' });
  },
  
  // 创建提示词
  createPrompt: (promptData) => {
    return createRequest('/prompts', {
      method: 'POST',
      body: JSON.stringify(promptData)
    });
  },
  
  // 自动保存提示词
  autoSavePrompt: (promptData) => {
    return createRequest('/prompts/auto-save', {
      method: 'POST',
      body: JSON.stringify(promptData)
    });
  },
  
  // 批量获取提示词
  getBatchPrompts: (ids) => {
    return createRequest('/prompts/batch', {
      method: 'POST',
      body: JSON.stringify({ ids })
    });
  },
  
  // 获取最近使用的提示词
  getRecentPrompts: () => {
    return createRequest('/prompts/recent', { method: 'GET' });
  },
  
  // 快速搜索提示词
  quickSearchPrompts: (query) => {
    return createRequest(`/prompts/quick-search?query=${encodeURIComponent(query)}`, { method: 'GET' });
  },
  
  // 优化提示词
  enhancePrompt: (promptData) => {
    return createRequest('/prompts/enhance', {
      method: 'POST',
      body: JSON.stringify(promptData)
    });
  },
  
  // 获取单个提示词
  getPrompt: (id) => {
    return createRequest(`/prompts/${id}`, { method: 'GET' });
  },
  
  // 更新提示词
  updatePrompt: (id, promptData) => {
    return createRequest(`/prompts/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(promptData)
    });
  },
  
  // 删除提示词
  deletePrompt: (id) => {
    return createRequest(`/prompts/${id}`, { method: 'DELETE' });
  },
  
  // 切换收藏状态
  toggleFavorite: (id) => {
    return createRequest(`/prompts/${id}/favorite`, { method: 'PATCH' });
  },
  
  // 增加使用次数
  incrementUsage: (id) => {
    return createRequest(`/prompts/${id}/usage`, { method: 'PATCH' });
  }
};

// 标签相关API
export const tagAPI = {
  // 获取标签列表
  getTags: () => {
    return createRequest('/tags', { method: 'GET' });
  },
  
  // 创建标签
  createTag: (tagData) => {
    return createRequest('/tags', {
      method: 'POST',
      body: JSON.stringify(tagData)
    });
  },
  
  // 获取单个标签
  getTag: (id) => {
    return createRequest(`/tags/${id}`, { method: 'GET' });
  },
  
  // 更新标签
  updateTag: (id, tagData) => {
    return createRequest(`/tags/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(tagData)
    });
  },
  
  // 删除标签
  deleteTag: (id) => {
    return createRequest(`/tags/${id}`, { method: 'DELETE' });
  },
  
  // 获取标签的提示词
  getTagPrompts: (id, params) => {
    const queryString = params ? `?${new URLSearchParams(params).toString()}` : '';
    return createRequest(`/tags/${id}/prompts${queryString}`, { method: 'GET' });
  }
};

// 提示词优化相关API
export const optimizationAPI = {
  // 获取客户端配置
  getConfig: () => {
    return createRequest('/prompt-optimization/config', { method: 'GET' });
  },
  
  // 优化提示词
  optimizePrompt: (promptData) => {
    return createRequest('/prompt-optimization', {
      method: 'POST',
      body: JSON.stringify(promptData)
    });
  },
  
  // 获取优化历史
  getHistory: () => {
    return createRequest('/prompt-optimization/history', { method: 'GET' });
  },
  
  // 获取单个优化历史
  getHistoryById: (id) => {
    return createRequest(`/prompt-optimization/history/${id}`, { method: 'GET' });
  },
  
  // 评价优化结果
  rateOptimization: (id, ratingData) => {
    return createRequest(`/prompt-optimization/history/${id}/rate`, {
      method: 'POST',
      body: JSON.stringify(ratingData)
    });
  },
  
  // 管理API密钥
  manageApiKey: (keyData) => {
    return createRequest('/prompt-optimization/api-keys', {
      method: 'POST',
      body: JSON.stringify(keyData)
    });
  },
  
  // 获取API密钥
  getApiKeys: () => {
    return createRequest('/prompt-optimization/api-keys', { method: 'GET' });
  },
  
  // 删除API密钥
  deleteApiKey: (id) => {
    return createRequest(`/prompt-optimization/api-keys/${id}`, { method: 'DELETE' });
  }
};

// 导出API
self.promptAPI = promptAPI; 